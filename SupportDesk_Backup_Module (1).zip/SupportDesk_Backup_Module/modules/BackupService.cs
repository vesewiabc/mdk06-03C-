﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace SupportDesk.modules
{
    /// <summary>
    /// Резервное копирование БД (teh_db.db). Вся логика модуля находится здесь.
    /// Существующие таблицы и формы не затрагиваются.
    /// </summary>
    internal static class BackupService
    {
        #region Пути и настройки по умолчанию
        private const string DbFileName = "teh_db.db";
        private const string BackupPrefix = "teh_db_";
        private const string PreRestorePrefix = "prerestore_";
        private const int PreRestoreKeep = 3;

        // Полный путь к БД фиксируется один раз при первом обращении, чтобы
        // смена текущей папки (например, после OpenFileDialog) не повлияла на копирование.
        private static readonly string DbPath = Path.GetFullPath(DbFileName);

        public static string BackupDir
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "backups"); }
        }

        private static string SettingsFile { get { return Path.Combine(BackupDir, "backup.settings"); } }
        private static string LogFile { get { return Path.Combine(BackupDir, "backup.log"); } }
        #endregion

        #region Настройки (хранятся в backups\backup.settings)
        public static bool AutoEnabled { get; set; } = true;
        public static int KeepCount { get; set; } = 10;
        public static int IntervalHours { get; set; } = 4;
        public static string ExtraFolder { get; set; } = string.Empty;

        public static void LoadSettings()
        {
            try
            {
                if (!File.Exists(SettingsFile)) return;
                foreach (string line in File.ReadAllLines(SettingsFile, Encoding.UTF8))
                {
                    int i = line.IndexOf('=');
                    if (i <= 0) continue;
                    string key = line.Substring(0, i).Trim();
                    string val = line.Substring(i + 1).Trim();
                    int n;
                    switch (key)
                    {
                        case "AutoEnabled": AutoEnabled = val != "0"; break;
                        case "KeepCount": if (int.TryParse(val, out n) && n >= 1 && n <= 100) KeepCount = n; break;
                        case "IntervalHours": if (int.TryParse(val, out n) && n >= 1 && n <= 168) IntervalHours = n; break;
                        case "ExtraFolder": ExtraFolder = val; break;
                    }
                }
            }
            catch (Exception ex) { Log("Настройки", "Ошибка чтения: " + ex.Message); }
        }

        public static void SaveSettings()
        {
            try
            {
                Directory.CreateDirectory(BackupDir);
                File.WriteAllLines(SettingsFile, new[]
                {
                    "AutoEnabled=" + (AutoEnabled ? "1" : "0"),
                    "KeepCount=" + KeepCount,
                    "IntervalHours=" + IntervalHours,
                    "ExtraFolder=" + ExtraFolder
                }, Encoding.UTF8);
                RestartTimer();
            }
            catch (Exception ex) { Log("Настройки", "Ошибка записи: " + ex.Message); }
        }
        #endregion

        #region Автоматическое копирование
        private static readonly object Sync = new object();
        private static Timer _timer;

        /// <summary>Вызывается один раз при запуске приложения (Program.Main).</summary>
        public static void Start()
        {
            LoadSettings();
            if (!AutoEnabled) return;
            ThreadPool.QueueUserWorkItem(delegate { CreateBackup("авто: запуск", true); });
            RestartTimer();
        }

        /// <summary>Вызывается при завершении приложения (Application.ApplicationExit).</summary>
        public static void Stop()
        {
            if (_timer != null) { _timer.Dispose(); _timer = null; }
            if (AutoEnabled) CreateBackup("авто: выход", true);
        }

        private static void RestartTimer()
        {
            if (_timer != null) { _timer.Dispose(); _timer = null; }
            if (!AutoEnabled) return;
            TimeSpan period = TimeSpan.FromHours(IntervalHours);
            _timer = new Timer(delegate { CreateBackup("авто: по расписанию", true); }, null, period, period);
        }
        #endregion

        #region Создание копии
        public sealed class Result
        {
            public bool Ok;
            public bool Skipped;
            public string Path;
            public string Message;
        }

        /// <summary>
        /// Создаёт копию БД. skipIfUnchanged: не создавать копию, если БД не менялась
        /// с момента последней копии (для автоматических запусков).
        /// </summary>
        public static Result CreateBackup(string reason, bool skipIfUnchanged)
        {
            lock (Sync)
            {
                try
                {
                    if (!File.Exists(DbPath))
                        return Fail(reason, "Файл базы данных не найден: " + DbPath);

                    Directory.CreateDirectory(BackupDir);

                    if (skipIfUnchanged)
                    {
                        FileInfo last = ListBackups().FirstOrDefault(f => f.Name.StartsWith(BackupPrefix, StringComparison.OrdinalIgnoreCase));
                        if (last != null && last.LastWriteTime >= DbLastWrite())
                        {
                            Log(reason, "Пропущено: база не менялась с " + last.LastWriteTime.ToString("dd.MM.yyyy HH:mm"));
                            return new Result { Ok = true, Skipped = true, Message = "База не менялась с момента последней копии." };
                        }
                    }

                    string name = BackupPrefix + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + ".db";
                    string target = Path.Combine(BackupDir, name);
                    int suffix = 1;
                    while (File.Exists(target))
                        target = Path.Combine(BackupDir, name.Replace(".db", "_" + (suffix++) + ".db"));

                    CopyDatabase(DbPath, target);
                    ApplyRetention(BackupDir, BackupPrefix, KeepCount);

                    string extraNote = CopyToExtra(target);
                    Log(reason, "Создана копия " + Path.GetFileName(target) + extraNote);
                    return new Result { Ok = true, Path = target, Message = "Копия создана: " + Path.GetFileName(target) + extraNote };
                }
                catch (Exception ex)
                {
                    return Fail(reason, ex.Message);
                }
            }
        }

        private static string CopyToExtra(string source)
        {
            if (string.IsNullOrWhiteSpace(ExtraFolder)) return string.Empty;
            try
            {
                if (!Directory.Exists(ExtraFolder))
                    return " (доп. папка недоступна: " + ExtraFolder + ")";
                File.Copy(source, Path.Combine(ExtraFolder, Path.GetFileName(source)), true);
                ApplyRetention(ExtraFolder, BackupPrefix, KeepCount);
                return " + доп. папка";
            }
            catch (Exception ex)
            {
                return " (ошибка копирования в доп. папку: " + ex.Message + ")";
            }
        }

        private static Result Fail(string reason, string message)
        {
            Log(reason, "ОШИБКА: " + message);
            return new Result { Ok = false, Message = message };
        }

        private static DateTime DbLastWrite()
        {
            DateTime t = File.GetLastWriteTime(DbPath);
            foreach (string ext in new[] { "-wal", "-journal" })
            {
                string f = DbPath + ext;
                if (File.Exists(f) && File.GetLastWriteTime(f) > t) t = File.GetLastWriteTime(f);
            }
            return t;
        }
        #endregion

        #region Восстановление
        /// <summary>
        /// Восстанавливает БД из выбранной копии. Перед заменой делает страховочную копию
        /// текущей БД (prerestore_*.db). Работает через API резервного копирования SQLite,
        /// поэтому файл БД не заменяется «на лету».
        /// </summary>
        public static Result Restore(string backupFile)
        {
            lock (Sync)
            {
                try
                {
                    if (!File.Exists(backupFile))
                        return Fail("Восстановление", "Файл копии не найден.");

                    string problem = ValidateBackup(backupFile);
                    if (problem != null)
                        return Fail("Восстановление", problem);

                    Directory.CreateDirectory(BackupDir);
                    string safety = Path.Combine(BackupDir, PreRestorePrefix + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + ".db");
                    CopyDatabase(DbPath, safety);
                    ApplyRetention(BackupDir, PreRestorePrefix, PreRestoreKeep);

                    using (SQLiteConnection src = new SQLiteConnection(ConnString(backupFile, true)))
                    using (SQLiteConnection dst = new SQLiteConnection(ConnString(DbPath, false)))
                    {
                        src.Open();
                        dst.Open();
                        src.BackupDatabase(dst, "main", "main", -1, null, 0);
                    }
                    SQLiteConnection.ClearAllPools();

                    Log("Восстановление", "База восстановлена из " + Path.GetFileName(backupFile) +
                        " (страховочная копия: " + Path.GetFileName(safety) + ")");
                    return new Result
                    {
                        Ok = true,
                        Path = safety,
                        Message = "База восстановлена из " + Path.GetFileName(backupFile) +
                                  ".\nСтраховочная копия прежней базы: " + Path.GetFileName(safety)
                    };
                }
                catch (Exception ex)
                {
                    string msg = ex.Message;
                    if (msg.IndexOf("locked", StringComparison.OrdinalIgnoreCase) >= 0)
                        msg += "\nБаза занята другим процессом или окном. Закройте остальные окна приложения и повторите.";
                    return Fail("Восстановление", msg);
                }
            }
        }

        /// <summary>Возвращает текст проблемы или null, если файл можно использовать.</summary>
        private static string ValidateBackup(string file)
        {
            try
            {
                using (SQLiteConnection c = new SQLiteConnection(ConnString(file, true)))
                {
                    c.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("PRAGMA integrity_check;", c))
                    {
                        string res = Convert.ToString(cmd.ExecuteScalar());
                        if (!string.Equals(res, "ok", StringComparison.OrdinalIgnoreCase))
                            return "Файл копии повреждён (проверка целостности: " + res + ").";
                    }
                    HashSet<string> have = TableNames(c);
                    using (SQLiteConnection live = new SQLiteConnection(ConnString(DbPath, true)))
                    {
                        live.Open();
                        string[] missing = TableNames(live).Where(t => !have.Contains(t)).ToArray();
                        if (missing.Length > 0)
                            return "В выбранном файле нет таблиц текущей базы: " + string.Join(", ", missing) +
                                   ". Это не копия SupportDesk.";
                    }
                }
                SQLiteConnection.ClearAllPools();
                return null;
            }
            catch (Exception ex)
            {
                return "Не удалось прочитать файл как базу SQLite: " + ex.Message;
            }
        }

        private static HashSet<string> TableNames(SQLiteConnection c)
        {
            HashSet<string> set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (SQLiteCommand cmd = new SQLiteCommand(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';", c))
            using (SQLiteDataReader r = cmd.ExecuteReader())
            {
                while (r.Read()) set.Add(r.GetString(0));
            }
            return set;
        }
        #endregion

        #region Вспомогательное
        private static string ConnString(string file, bool readOnly)
        {
            return "Data Source=" + file + ";Pooling=False;" + (readOnly ? "Read Only=True;" : string.Empty);
        }

        /// <summary>Копирует БД через API SQLite во временный файл, проверяет и переименовывает.</summary>
        private static void CopyDatabase(string from, string to)
        {
            string tmp = to + ".tmp";
            try
            {
                if (File.Exists(tmp)) File.Delete(tmp);
                using (SQLiteConnection src = new SQLiteConnection(ConnString(from, true)))
                using (SQLiteConnection dst = new SQLiteConnection(ConnString(tmp, false)))
                {
                    src.Open();
                    dst.Open();
                    src.BackupDatabase(dst, "main", "main", -1, null, 0);
                    using (SQLiteCommand cmd = new SQLiteCommand("PRAGMA integrity_check;", dst))
                    {
                        string res = Convert.ToString(cmd.ExecuteScalar());
                        if (!string.Equals(res, "ok", StringComparison.OrdinalIgnoreCase))
                            throw new InvalidOperationException("Копия не прошла проверку целостности: " + res);
                    }
                }
                SQLiteConnection.ClearAllPools();
                File.Move(tmp, to);
            }
            finally
            {
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
            }
        }

        /// <summary>Копии, новые первыми.</summary>
        public static List<FileInfo> ListBackups()
        {
            if (!Directory.Exists(BackupDir)) return new List<FileInfo>();
            return new DirectoryInfo(BackupDir)
                .GetFiles("*.db")
                .Where(f => f.Name.StartsWith(BackupPrefix, StringComparison.OrdinalIgnoreCase)
                         || f.Name.StartsWith(PreRestorePrefix, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(f => f.LastWriteTime)
                .ToList();
        }

        private static void ApplyRetention(string dir, string prefix, int keep)
        {
            try
            {
                FileInfo[] files = new DirectoryInfo(dir).GetFiles(prefix + "*.db")
                    .OrderByDescending(f => f.LastWriteTime).ToArray();
                for (int i = keep; i < files.Length; i++)
                {
                    try { files[i].Delete(); } catch { }
                }
            }
            catch { }
        }

        private static void Log(string what, string text)
        {
            try
            {
                Directory.CreateDirectory(BackupDir);
                FileInfo fi = new FileInfo(LogFile);
                if (fi.Exists && fi.Length > 256 * 1024)
                {
                    string[] tail = File.ReadAllLines(LogFile).Reverse().Take(200).Reverse().ToArray();
                    File.WriteAllLines(LogFile, tail, Encoding.UTF8);
                }
                File.AppendAllText(LogFile,
                    DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss") + " | " + what + " | " + text + Environment.NewLine,
                    Encoding.UTF8);
            }
            catch { }
        }
        #endregion
    }
}
