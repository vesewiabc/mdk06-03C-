﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace SupportDesk.modules
{
    /// <summary>
    /// Окно управления резервными копиями БД. Создаётся полностью в коде (без Designer),
    /// чтобы не затрагивать существующие формы.
    /// </summary>
    internal sealed class BackupForm : Form
    {
        private readonly ListView _list = new ListView();
        private readonly Label _status = new Label();
        private readonly CheckBox _auto = new CheckBox();
        private readonly NumericUpDown _interval = new NumericUpDown();
        private readonly NumericUpDown _keep = new NumericUpDown();
        private readonly TextBox _extra = new TextBox();

        public BackupForm()
        {
            Text = "Резервные копии базы данных";
            Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            BackColor = Color.White;
            ClientSize = new Size(560, 470);

            BuildList();
            BuildButtons();
            BuildAutoGroup();

            _status.Location = new Point(12, 442);
            _status.Size = new Size(536, 22);
            _status.ForeColor = Color.DimGray;
            Controls.Add(_status);

            Load += delegate
            {
                BackupService.LoadSettings();
                _auto.Checked = BackupService.AutoEnabled;
                _interval.Value = BackupService.IntervalHours;
                _keep.Value = BackupService.KeepCount;
                _extra.Text = BackupService.ExtraFolder;
                RefreshList();
            };
        }

        #region Построение интерфейса
        private void BuildList()
        {
            Label caption = new Label { Text = "Сохранённые копии (новые сверху):", Location = new Point(12, 10), AutoSize = true };
            Controls.Add(caption);

            _list.Location = new Point(12, 32);
            _list.Size = new Size(536, 160);
            _list.View = View.Details;
            _list.FullRowSelect = true;
            _list.MultiSelect = false;
            _list.HideSelection = false;
            _list.Columns.Add("Файл", 270);
            _list.Columns.Add("Дата", 130);
            _list.Columns.Add("Размер", 100);
            Controls.Add(_list);
        }

        private void BuildButtons()
        {
            Button create = MakeButton("Создать копию сейчас", 12, 200, 262);
            create.Click += CreateClick;
            Button open = MakeButton("Открыть папку копий", 286, 200, 262);
            open.Click += OpenFolderClick;
            Button restoreSel = MakeButton("Восстановить из выбранной", 12, 240, 262);
            restoreSel.Click += RestoreSelectedClick;
            Button restoreFile = MakeButton("Восстановить из файла...", 286, 240, 262);
            restoreFile.Click += RestoreFileClick;
            Controls.AddRange(new Control[] { create, open, restoreSel, restoreFile });
        }

        private void BuildAutoGroup()
        {
            GroupBox g = new GroupBox { Text = "Автоматическое копирование", Location = new Point(12, 288), Size = new Size(536, 148) };

            _auto.Text = "Включено (при запуске, при выходе и по расписанию)";
            _auto.Location = new Point(12, 24);
            _auto.AutoSize = true;

            Label l1 = new Label { Text = "Интервал, часов:", Location = new Point(12, 56), AutoSize = true };
            _interval.Location = new Point(150, 53);
            _interval.Size = new Size(60, 24);
            _interval.Minimum = 1;
            _interval.Maximum = 168;

            Label l2 = new Label { Text = "Хранить копий:", Location = new Point(250, 56), AutoSize = true };
            _keep.Location = new Point(380, 53);
            _keep.Size = new Size(60, 24);
            _keep.Minimum = 1;
            _keep.Maximum = 100;

            Label l3 = new Label { Text = "Доп. папка (флешка, сетевой диск):", Location = new Point(12, 86), AutoSize = true };
            _extra.Location = new Point(12, 108);
            _extra.Size = new Size(300, 24);
            Button browse = MakeButton("Обзор...", 320, 106, 90);
            browse.Click += BrowseClick;
            Button save = MakeButton("Сохранить", 418, 106, 106);
            save.Click += SaveSettingsClick;

            g.Controls.AddRange(new Control[] { _auto, l1, _interval, l2, _keep, l3, _extra, browse, save });
            Controls.Add(g);
        }

        private static Button MakeButton(string text, int x, int y, int w)
        {
            Button b = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(w, 32),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.DodgerBlue,
                ForeColor = Color.White,
                Cursor = Cursors.Hand,
                Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 204)
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }
        #endregion

        #region Обработчики
        private void RefreshList()
        {
            _list.Items.Clear();
            foreach (FileInfo f in BackupService.ListBackups())
            {
                ListViewItem item = new ListViewItem(f.Name) { Tag = f.FullName };
                item.SubItems.Add(f.LastWriteTime.ToString("dd.MM.yyyy HH:mm:ss"));
                item.SubItems.Add((f.Length / 1024.0).ToString("0.0") + " КБ");
                _list.Items.Add(item);
            }
            _status.Text = _list.Items.Count == 0 ? "Копий пока нет." : "Копий: " + _list.Items.Count;
        }

        private void CreateClick(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            BackupService.Result r;
            try { r = BackupService.CreateBackup("ручная", false); }
            finally { Cursor = Cursors.Default; }

            RefreshList();
            if (r.Ok)
            {
                _status.Text = r.Message;
                AppLog("Создана копия " + (r.Path == null ? string.Empty : Path.GetFileName(r.Path)));
            }
            else
            {
                _status.Text = "Ошибка копирования";
                MessageBox.Show("Не удалось создать копию:\n" + r.Message, "Резервное копирование",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OpenFolderClick(object sender, EventArgs e)
        {
            try
            {
                Directory.CreateDirectory(BackupService.BackupDir);
                System.Diagnostics.Process.Start("explorer.exe", "\"" + BackupService.BackupDir + "\"");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Резервное копирование", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RestoreSelectedClick(object sender, EventArgs e)
        {
            if (_list.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выберите копию в списке.", "Резервное копирование",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DoRestore((string)_list.SelectedItems[0].Tag);
        }

        private void RestoreFileClick(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Выберите файл копии базы данных";
                dlg.Filter = "База данных SQLite (*.db)|*.db|Все файлы (*.*)|*.*";
                dlg.RestoreDirectory = true;
                if (Directory.Exists(BackupService.BackupDir)) dlg.InitialDirectory = BackupService.BackupDir;
                if (dlg.ShowDialog(this) == DialogResult.OK) DoRestore(dlg.FileName);
            }
        }

        private void DoRestore(string file)
        {
            DialogResult ask = MessageBox.Show(
                "Текущая база данных будет заменена данными из файла:\n" + Path.GetFileName(file) +
                "\n\nВсе изменения, сделанные после создания этой копии, будут потеряны.\n" +
                "Перед заменой будет автоматически создана страховочная копия текущей базы.\n\nПродолжить?",
                "Восстановление базы", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (ask != DialogResult.Yes) return;

            Cursor = Cursors.WaitCursor;
            BackupService.Result r;
            try { r = BackupService.Restore(file); }
            finally { Cursor = Cursors.Default; }

            RefreshList();
            if (!r.Ok)
            {
                _status.Text = "Восстановление не выполнено";
                MessageBox.Show("Не удалось восстановить базу:\n" + r.Message, "Восстановление базы",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            AppLog("База восстановлена из " + Path.GetFileName(file));
            DialogResult restart = MessageBox.Show(
                r.Message + "\n\nЧтобы изменения применились, приложение нужно перезапустить.\nЗакрыть приложение сейчас?",
                "Восстановление базы", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (restart == DialogResult.Yes) Application.Exit();
        }

        private void BrowseClick(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dlg = new FolderBrowserDialog())
            {
                dlg.Description = "Выберите дополнительную папку для копий";
                if (Directory.Exists(_extra.Text)) dlg.SelectedPath = _extra.Text;
                if (dlg.ShowDialog(this) == DialogResult.OK) _extra.Text = dlg.SelectedPath;
            }
        }

        private void SaveSettingsClick(object sender, EventArgs e)
        {
            string extra = _extra.Text.Trim();
            if (extra.Length > 0 && !Directory.Exists(extra))
            {
                MessageBox.Show("Дополнительная папка не найдена:\n" + extra, "Резервное копирование",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            BackupService.AutoEnabled = _auto.Checked;
            BackupService.IntervalHours = (int)_interval.Value;
            BackupService.KeepCount = (int)_keep.Value;
            BackupService.ExtraFolder = extra;
            BackupService.SaveSettings();
            _status.Text = "Настройки сохранены.";
        }
        #endregion

        /// <summary>Запись в общий журнал приложения (logs.txt) в его формате. Ошибки журнала игнорируются.</summary>
        private static void AppLog(string text)
        {
            try
            {
                File.AppendAllText(Logs.file,
                    "[Резервное копирование]" + text + " (" + DataUsers.Initials + ") (" +
                    DateTime.Now.ToString("dd.MM.yyyy HH:mm") + ")" + Environment.NewLine);
            }
            catch { }
        }
    }
}
