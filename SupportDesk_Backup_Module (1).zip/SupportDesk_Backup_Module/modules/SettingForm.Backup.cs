﻿using System;
using System.Drawing;
using System.Windows.Forms;
using SupportDesk.modules;

namespace SupportDesk.forms
{
    // Часть SettingForm для модуля резервного копирования.
    // Добавляет в окно «Настройки» группу с одной кнопкой; Designer-файл не меняется.
    public partial class SettingForm
    {
        private void InitBackupUi()
        {
            const int extra = 62;
            MinimumSize = new Size(MinimumSize.Width, MinimumSize.Height + extra);
            MaximumSize = new Size(MaximumSize.Width, MaximumSize.Height + extra);
            ClientSize = new Size(ClientSize.Width, ClientSize.Height + extra);

            GroupBox g = new GroupBox
            {
                Text = "Резервные копии",
                Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204),
                Location = new Point(10, 373),
                Size = new Size(212, 52)
            };

            ExpUI.dll.ExpUIButton b = new ExpUI.dll.ExpUIButton();
            b.BackColor = Color.DodgerBlue;
            b.BorderSize = 1;
            b.ClickColor = Color.FromArgb(80, 255, 255, 255);
            b.ColorTextForBorder = Color.White;
            b.Cursor = Cursors.Hand;
            b.DisableColor = Color.FromArgb(80, 255, 255, 255);
            b.Font = new Font("Arial", 9.75F, FontStyle.Bold);
            b.ForeColor = Color.White;
            b.HoverColor = Color.FromArgb(25, 0, 0, 0);
            b.Image = null;
            b.Location = new Point(6, 14);
            b.Name = "buttonBackup";
            b.Remember = false;
            b.ResponsiveFontOn = new Font("Arial", 12F, FontStyle.Bold);
            b.ResponsiveText = false;
            b.Size = new Size(200, 32);
            b.StyleButton = ExpUI.dll.ExpUIButton.styleButton.Standart;
            b.Text = "Управление копиями";
            b.TextAlign = ExpUI.dll.ExpUIButton.textAlign.MiddleCenter;
            b.Click += ButtonBackup_Click;

            g.Controls.Add(b);
            Controls.Add(g);
        }

        private void ButtonBackup_Click(object sender, EventArgs e)
        {
            using (BackupForm f = new BackupForm())
            {
                _ = f.ShowDialog(this);
            }
        }
    }
}
